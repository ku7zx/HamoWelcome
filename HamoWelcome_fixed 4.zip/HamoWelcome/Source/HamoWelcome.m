#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "HamoWelcomeController.h"

__attribute__((constructor)) static void HamoWelcomeInit() {
    NSLog(@"[HamoWelcome] Injected into Video Star");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        UIViewController *topVC = [UIApplication sharedApplication].keyWindow.rootViewController;
        if (topVC) {
            HamoWelcomeController *vc = [[HamoWelcomeController alloc] init];
            vc.modalPresentationStyle = UIModalPresentationOverFullScreen;
            [topVC presentViewController:vc animated:YES completion:nil];
        }
    });
}
