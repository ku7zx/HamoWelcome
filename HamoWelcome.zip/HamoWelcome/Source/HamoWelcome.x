// ==============================================================
//  HamoWelcome — Main Tweak Source
//  File        : HamoWelcome.x  (Logos / Objective-C)
//  Developer   : حمو الكردي (Hamo Al-Kurdi)
//  Target App  : Video Star — com.luckyclan.videostar
// ==============================================================
//
//  WHAT THIS FILE DOES:
//  This is the entry point for the HamoWelcome dylib.
//  When Video Star launches, Substrate/Dopamine injects this dylib
//  and Logos hooks into the specified class methods below.
//
//  HOW LOGOS WORKS:
//    %hook ClassName       — hooks into an existing ObjC class
//    %orig                 — calls the original (unhooked) method
//    %new                  — adds a new method to an existing class
//    %ctor                 — constructor: runs once when dylib loads
//    %dtor                 — destructor: runs when dylib is unloaded
//    %group / %init        — organise hooks into named groups
//
//  CURRENT STATUS: Project skeleton — UI code not written yet.
//  Next step: Add the HamoWelcome welcome screen logic here.
// ==============================================================

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

// ── Import custom headers as they are created ──────────────────
// #import "../Headers/HamoWelcomeController.h"

// ==============================================================
//  MARK: — Constructor
//  %ctor runs once when the dylib is injected into the process.
//  Use it to register observers or perform one-time setup.
// ==============================================================
%ctor {
    // Initialise the default hook group.
    // When you add %group blocks, replace %init with %init(GroupName).
    %init;

    // TODO: Perform any one-time setup here (e.g. load preferences,
    //       register NSNotificationCenter observers).
}

// ==============================================================
//  MARK: — Hook placeholder
//  Replace "NSObject" with the real Video Star class you want to hook.
//  Example: hook the root view controller to present the welcome screen.
// ==============================================================
/*
%hook <#TargetClassName#>

- (void)<#targetMethod#> {
    // Call the original implementation first.
    %orig;

    // TODO: Present the HamoWelcome welcome screen here.
}

%end
*/

// ==============================================================
//  END OF FILE
//  All new hooks should be added above this line.
// ==============================================================
