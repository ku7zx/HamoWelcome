// ==============================================================
//  HamoWelcomeController.m
//  Implementation of the welcome-screen view controller.
//  Developer: حمو الكردي (Hamo Al-Kurdi)
// ==============================================================
//
//  STATUS: Skeleton — UI implementation not written yet.
//  This file is ready for development.
//  All methods below are stubs with TODO markers.
// ==============================================================

#import "../Headers/HamoWelcomeController.h"

// ── Social link constants ──────────────────────────────────────
static NSString * const kTelegramURL   = @"https://t.me/hamoku7";
static NSString * const kInstagramURL  = @"https://www.instagram.com/mx.ku7";
static NSString * const kYouTubeURL    = @"https://youtube.com/@mx.ku7";
static NSString * const kTikTokURL     = @"https://www.tiktok.com/@ku7zm";

@implementation HamoWelcomeController

// ── Factory ─────────────────────────────────────────────────────
+ (instancetype)controller {
    return [[self alloc] initWithNibName:nil bundle:nil];
}

// ── Lifecycle ───────────────────────────────────────────────────
- (void)viewDidLoad {
    [super viewDidLoad];
    // TODO: Build the welcome UI programmatically here.
    //       See Headers/HamoWelcomeController.h for the full interface.
}

// ── Actions ─────────────────────────────────────────────────────

- (void)dismissWelcomeScreen {
    // TODO: Animate out and dismiss.
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)openTelegram {
    [self openURL:kTelegramURL];
}

- (void)openInstagram {
    [self openURL:kInstagramURL];
}

- (void)openYouTube {
    [self openURL:kYouTubeURL];
}

- (void)openTikTok {
    [self openURL:kTikTokURL];
}

// ── Private helpers ─────────────────────────────────────────────

/// Opens a URL string in Safari or the associated native app.
- (void)openURL:(NSString *)urlString {
    NSURL *url = [NSURL URLWithString:urlString];
    if (!url) { return; }
    if ([[UIApplication sharedApplication] canOpenURL:url]) {
        [[UIApplication sharedApplication] openURL:url
                                           options:@{}
                                 completionHandler:nil];
    }
}

@end
