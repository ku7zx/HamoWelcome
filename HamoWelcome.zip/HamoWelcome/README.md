# HamoWelcome 🔥

**Tweak iOS احترافي لتطبيق Video Star**
المطور: حمو الكردي

---

## ما هذا المشروع؟

HamoWelcome هو iOS Tweak (مكتبة ديناميكية `.dylib`) مبني باستخدام **Theos** و**Logos**،
يُحقن في تطبيق **Video Star** (`com.luckyclan.videostar`) عند فتحه على جهاز Jailbroken،
ويعرض شاشة ترحيب مخصصة مع روابط قنوات المطور.

---

## هيكل المشروع

```
HamoWelcome/
│
├── Makefile                    ← إعدادات بناء Theos الكاملة
├── control                     ← بيانات حزمة الـ .deb (الاسم، الإصدار، الوصف)
├── HamoWelcome.plist           ← فلتر الحقن (يحدد: Video Star فقط)
│
├── Source/
│   ├── HamoWelcome.x           ← نقطة الدخول الرئيسية (Logos hooks)
│   └── HamoWelcomeController.m ← منطق شاشة الترحيب
│
├── Headers/
│   ├── HamoWelcomeController.h ← تعريف واجهة الكنترولر
│   └── VideoStarHeaders.h      ← هيدرز Video Star (تُملأ بعد class-dump)
│
├── Images/                     ← أصول الصور (شعار، خلفيات)
│   └── logo.png                ← شعار HamoWelcome
│
├── Resources/                  ← ملفات تُنسخ داخل حزمة الـ .deb
│
├── README.md                   ← هذا الملف
└── LICENSE                     ← رخصة الاستخدام
```

---

## وظيفة كل ملف

| الملف | الوظيفة |
|---|---|
| `Makefile` | يخبر Theos بكيفية تجميع المشروع وحزمه |
| `control` | معلومات الحزمة لـ Cydia / Sileo / Zebra |
| `HamoWelcome.plist` | يحصر الحقن في Video Star فقط |
| `Source/HamoWelcome.x` | الـ Hooks الرئيسية (Logos syntax) |
| `Source/HamoWelcomeController.m` | منطق وتصميم شاشة الترحيب |
| `Headers/HamoWelcomeController.h` | تعريف الكلاس الرئيسي |
| `Headers/VideoStarHeaders.h` | هيدرز Video Star المعكوسة |
| `Images/` | أصول الصور |

---

## متطلبات البناء

- جهاز Mac أو Linux مع **Theos** مثبت
- `ldid` و `dpkg` مثبتان
- iOS SDK (عبر Xcode أو theos-jailed)
- جهاز iPhone Jailbroken (iOS 15+) للاختبار

---

## خطوات البناء

```bash
# 1. ثبّت Theos
bash -c "$(curl -fsSL https://raw.githubusercontent.com/theos/theos/master/bin/install-theos)"

# 2. ادخل إلى مجلد المشروع
cd HamoWelcome

# 3. ابنِ المشروع
make

# 4. احزمه كـ .deb
make package

# 5. ثبّته على جهازك (عبر SSH)
export THEOS_DEVICE_IP=<IP_JAILBROKEN_DEVICE>
make install
```

---

## حالة التطوير

- [x] هيكل المشروع
- [x] Makefile + control + plist
- [x] Headers skeleton
- [ ] واجهة شاشة الترحيب (قيد التطوير)
- [ ] ربط الروابط الاجتماعية
- [ ] تحريك وتنشيط الواجهة
- [ ] نشر على ريبو Cydia

---

## المطور

**حمو الكردي** — Video Star Content Creator & iOS Developer
- Telegram: [@hamoku7](https://t.me/hamoku7)
- YouTube: [@mx.ku7](https://youtube.com/@mx.ku7)
- Instagram: [@mx.ku7](https://www.instagram.com/mx.ku7)
- TikTok: [@ku7zm](https://www.tiktok.com/@ku7zm)
