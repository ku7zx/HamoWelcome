// ==============================================================
//  VideoStarHeaders.h
//  Reverse-engineered private headers for Video Star.
//  Developer: حمو الكردي (Hamo Al-Kurdi)
// ==============================================================
//
//  PURPOSE:
//  Declares the ObjC classes and methods discovered through
//  class-dump or Frida on Video Star's binary.
//  Import this file in HamoWelcome.x to call Video Star internals.
//
//  HOW TO GET REAL HEADERS:
//  1. Copy VideoStar binary from /var/containers/Bundle/Application/.../
//  2. Run: class-dump -H -o ./Headers/ ./VideoStar
//  3. Replace the stubs below with the real declarations.
//
//  STATUS: Stubs only — fill in after class-dumping the binary.
// ==============================================================

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

// ==============================================================
//  MARK: — Root view controller stub
//  Replace "<#VSRootViewController#>" with the actual class name
//  found via class-dump.
// ==============================================================
/*
@interface <#VSRootViewController#> : UIViewController
- (void)<#someVideoStarMethod#>;
@end
*/

// ==============================================================
//  MARK: — App delegate stub
// ==============================================================
/*
@interface <#VSAppDelegate#> : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UIWindow *window;
@end
*/

// ==============================================================
//  Add more stubs here as you reverse-engineer the app.
// ==============================================================
