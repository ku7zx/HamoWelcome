// ==============================================================
//  HamoWelcomeController.h
//  Header for the main welcome-screen view controller.
//  Developer: حمو الكردي (Hamo Al-Kurdi)
// ==============================================================
//
//  PURPOSE:
//  Declares HamoWelcomeController — a UIViewController subclass
//  that will present the branded welcome / links screen when
//  Video Star launches.
//
//  STATUS: Interface skeleton — implementation not written yet.
//  Add method signatures here as the Source/*.m file grows.
// ==============================================================

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HamoWelcomeController : UIViewController

// ── Factory method ─────────────────────────────────────────────
// Returns a pre-configured instance ready to be presented.
+ (instancetype)controller;

// ── Dismiss ────────────────────────────────────────────────────
// Called when the user taps the "دخول الى ستار" (Enter) button.
// Dismisses the welcome screen and continues into Video Star.
- (void)dismissWelcomeScreen;

// ── Social link openers ────────────────────────────────────────
// Each method opens the corresponding platform URL.
// TODO: implement in Source/HamoWelcomeController.m
- (void)openTelegram;
- (void)openInstagram;
- (void)openYouTube;
- (void)openTikTok;

@end

NS_ASSUME_NONNULL_END
