# كيف تحصل على HAMO.dylib — خطوة بخطوة

## الطريقة: GitHub Actions (مجاناً بالكامل)

---

### الخطوة 1 — إنشاء حساب GitHub
اذهب إلى https://github.com وأنشئ حساباً مجانياً

---

### الخطوة 2 — إنشاء Repository جديد
1. اضغط **New repository**
2. اسم الـ repo: `HamoWelcome`
3. اجعله **Private** (خاص)
4. اضغط **Create repository**

---

### الخطوة 3 — رفع ملفات المشروع
في صفحة الـ repository الجديد:
1. اضغط **uploading an existing file**
2. ارفع كل ملفات مجلد HamoWelcome (اسحبهم كلهم مرة وحدة)
3. اضغط **Commit changes**

---

### الخطوة 4 — تشغيل البناء
1. اذهب إلى تبويب **Actions**
2. ستجد workflow اسمه **Build HamoWelcome Dylib**
3. اضغط **Run workflow** ← **Run workflow**
4. انتظر 3-5 دقائق

---

### الخطوة 5 — تحميل HAMO.dylib
1. بعد انتهاء البناء (علامة ✅ خضراء)
2. اضغط على اسم الـ workflow
3. في الأسفل قسم **Artifacts**
4. اضغط **HAMO-dylib-xxxxx**
5. حمّل الملف — يحتوي على:
   - `HAMO.dylib` — الملف المطلوب للحقن
   - `*.deb` — حزمة جاهزة للتثبيت عبر Cydia/Sileo

---

### تثبيت الـ .deb على iPhone
1. انقل ملف `.deb` إلى جهازك
2. افتح Filza أو iFile
3. اضغط على الملف ← **Install**
4. أو استخدم Cydia: **Manage** ← **Sources** ← **Local**

---

## ملاحظات
- كل مرة تعدّل الكود وترفعه، GitHub يبني نسخة جديدة تلقائياً
- الملفات تُحفظ 30 يوم
- GitHub يعطيك 2000 دقيقة مجانية شهرياً (أكثر من كافٍ)
