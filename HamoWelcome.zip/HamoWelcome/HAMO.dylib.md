# HAMO.dylib — معلومات الملف النهائي

## ما هو HAMO.dylib؟

`HAMO.dylib` هو الملف الثنائي المُجمَّع (compiled binary) الذي يُحقن في
تطبيق Video Star على جهاز iPhone المكسور (Jailbroken).

يحتوي على كل كود مشروع HamoWelcome بعد تجميعه.

---

## لماذا لا يمكن توليده هنا؟

تجميع ملف `.dylib` لنظام iOS يتطلب:

1. **Theos** — نظام بناء متخصص بـ iOS tweaks
2. **iOS SDK** — يأتي مع Xcode على macOS
3. **`clang` مع دعم arm64/arm64e** — لتجميع Objective-C لمعالجات Apple
4. **`ldid`** — لتوقيع الملف الثنائي
5. **`dpkg`** — لحزم الملف داخل .deb

هذه الأدوات لا تعمل على Linux/Replit لأنها تحتاج macOS SDK.

---

## كيف تجمّع HAMO.dylib على جهازك؟

```bash
# المتطلبات: Mac مع Xcode + Theos مثبت

# 1. اذهب إلى مجلد المشروع
cd HamoWelcome

# 2. جمّع المشروع
make

# الملف يُنتج في:
.theos/obj/debug/HamoWelcome.dylib

# 3. احزمه داخل .deb (يحتوي HAMO.dylib داخله)
make package

# الحزمة تُنتج في:
packages/com.hamokurd.HamoWelcome_1.0.0_iphoneos-arm.deb

# 4. ثبّته على iPhone
make install
```

---

## هيكل الـ .deb (يحتوي HAMO.dylib)

```
com.hamokurd.HamoWelcome_1.0.0_iphoneos-arm.deb
├── DEBIAN/
│   └── control
└── Library/
    ├── MobileSubstrate/DynamicLibraries/
    │   ├── HamoWelcome.dylib     ← الملف الثنائي المحقون
    │   └── HamoWelcome.plist     ← فلتر الحقن
    └── Application Support/HamoWelcome/
        └── logo.png
```

---

## ملاحظة

جميع ملفات المصدر في هذا المشروع جاهزة للبناء.
بمجرد تثبيت Theos على Mac، نفّذ `make package` وستحصل على `HAMO.dylib`.
