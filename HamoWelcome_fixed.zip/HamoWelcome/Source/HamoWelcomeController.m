// ==============================================================
//  HamoWelcomeController.m — واجهة ترحيب حمو الكردي
// ==============================================================

#import "../Headers/HamoWelcomeController.h"

static NSString * const kTelegramURL  = @"https://t.me/hamoku7";
static NSString * const kInstagramURL = @"https://www.instagram.com/mx.ku7";
static NSString * const kYouTubeURL   = @"https://youtube.com/@mx.ku7";
static NSString * const kTikTokURL    = @"https://www.tiktok.com/@ku7zm";

@interface HamoWelcomeController ()
@property (nonatomic, strong) UIButton *enterButton;
@end

@implementation HamoWelcomeController

+ (instancetype)controller {
    return [[self alloc] initWithNibName:nil bundle:nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self buildUI];
}

- (void)buildUI {
    // ── خلفية داكنة ───────────────────────────────────────────
    self.view.backgroundColor = [UIColor colorWithRed:0.05 green:0.05 blue:0.10 alpha:1.0];

    CGFloat W = self.view.bounds.size.width;
    CGFloat cy = 160;

    // ── دائرة الأفاتار HK ─────────────────────────────────────
    UIView *avatar = [[UIView alloc] initWithFrame:CGRectMake(W/2 - 50, cy - 50, 100, 100)];
    avatar.layer.cornerRadius = 50;
    avatar.clipsToBounds = YES;
    avatar.backgroundColor = [UIColor colorWithRed:0.40 green:0.20 blue:0.80 alpha:1.0];

    UILabel *hkLabel = [[UILabel alloc] initWithFrame:avatar.bounds];
    hkLabel.text = @"HK";
    hkLabel.textColor = [UIColor whiteColor];
    hkLabel.font = [UIFont boldSystemFontOfSize:34];
    hkLabel.textAlignment = NSTextAlignmentCenter;
    [avatar addSubview:hkLabel];
    [self.view addSubview:avatar];

    // ── اسم المستخدم ──────────────────────────────────────────
    UILabel *name = [[UILabel alloc] initWithFrame:CGRectMake(20, cy + 65, W - 40, 36)];
    name.text = @"حمو الكردي";
    name.textColor = [UIColor whiteColor];
    name.font = [UIFont boldSystemFontOfSize:22];
    name.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:name];

    UILabel *handle = [[UILabel alloc] initWithFrame:CGRectMake(20, cy + 103, W - 40, 24)];
    handle.text = @"@hamoku7";
    handle.textColor = [UIColor colorWithWhite:0.6 alpha:1.0];
    handle.font = [UIFont systemFontOfSize:15];
    handle.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:handle];

    // ── أزرار التواصل ─────────────────────────────────────────
    NSArray *titles  = @[@"تيليغرام", @"إنستغرام", @"يوتيوب", @"تيك توك"];
    NSArray *colors  = @[
        [UIColor colorWithRed:0.16 green:0.60 blue:0.93 alpha:1.0],
        [UIColor colorWithRed:0.83 green:0.25 blue:0.55 alpha:1.0],
        [UIColor colorWithRed:0.93 green:0.15 blue:0.15 alpha:1.0],
        [UIColor colorWithRed:0.10 green:0.10 blue:0.10 alpha:1.0],
    ];
    NSArray *actions = @[
        NSStringFromSelector(@selector(openTelegram)),
        NSStringFromSelector(@selector(openInstagram)),
        NSStringFromSelector(@selector(openYouTube)),
        NSStringFromSelector(@selector(openTikTok)),
    ];

    CGFloat btnY = cy + 145;
    for (NSInteger i = 0; i < titles.count; i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
        btn.frame = CGRectMake(24, btnY + i * 58, W - 48, 46);
        btn.backgroundColor = colors[i];
        btn.layer.cornerRadius = 14;
        btn.clipsToBounds = YES;
        [btn setTitle:titles[i] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont boldSystemFontOfSize:16];
        [btn addTarget:self
                action:NSSelectorFromString(actions[i])
      forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btn];
    }

    // ── زر دخول إلى ستار ──────────────────────────────────────
    UIButton *enterBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    enterBtn.frame = CGRectMake(24, btnY + titles.count * 58 + 14, W - 48, 46);
    enterBtn.backgroundColor = [UIColor colorWithRed:0.55 green:0.25 blue:0.95 alpha:1.0];
    enterBtn.layer.cornerRadius = 14;
    enterBtn.clipsToBounds = YES;
    [enterBtn setTitle:@"دخول الى ستار ✦" forState:UIControlStateNormal];
    [enterBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    enterBtn.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    [enterBtn addTarget:self
                 action:@selector(dismissWelcomeScreen)
       forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:enterBtn];
}

// ── Actions ──────────────────────────────────────────────────────

- (void)dismissWelcomeScreen {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)openTelegram  { [self openURL:kTelegramURL];  }
- (void)openInstagram { [self openURL:kInstagramURL]; }
- (void)openYouTube   { [self openURL:kYouTubeURL];   }
- (void)openTikTok    { [self openURL:kTikTokURL];    }

- (void)openURL:(NSString *)urlString {
    NSURL *url = [NSURL URLWithString:urlString];
    if (!url) return;
    [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
}

@end
