#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "HamoWelcomeController.h"

static void presentWelcome(void) {
    UIWindow *window = nil;
    for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
        if ([scene isKindOfClass:[UIWindowScene class]]) {
            UIWindowScene *ws = (UIWindowScene *)scene;
            for (UIWindow *w in ws.windows) {
                if (w.isKeyWindow) { window = w; break; }
            }
        }
    }
    if (!window) {
        window = [UIApplication sharedApplication].windows.firstObject;
    }

    UIViewController *root = window.rootViewController;
    while (root.presentedViewController) {
        root = root.presentedViewController;
    }

    if (root) {
        HamoWelcomeController *vc = [HamoWelcomeController controller];
        vc.modalPresentationStyle = UIModalPresentationOverFullScreen;
        vc.modalTransitionStyle   = UIModalTransitionStyleCrossDissolve;
        [root presentViewController:vc animated:YES completion:nil];
    }
}

__attribute__((constructor)) static void HamoWelcomeInit(void) {
    NSLog(@"[HamoWelcome] ✅ Injected into Video Star");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        presentWelcome();
    });
}
